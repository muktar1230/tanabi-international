# Tanabi International

Premium bilingual Balochi fashion e-commerce website.

## Run locally

```bash
npm install
npm run dev
```

Then open the local URL shown by Vite.

## Build

```bash
npm run build
npm run preview
```

## Deploy

This project is ready to upload to GitHub and import into Vercel.

> Note: the current app stores its demo catalog/settings/orders in browser local state/storage. A shared production database and secure admin authentication should be added before using it for real customer orders.
