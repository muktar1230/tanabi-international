import React, { useState, useEffect, useRef, useMemo } from "react";
import {
  ShoppingBag, X, Plus, Trash2, Edit2, Copy, Eye, Search, ChevronLeft,
  ChevronRight, Upload, Star, Sparkles, Award, Tag, Lock, Settings as SettingsIcon,
  Globe, Check, AlertCircle, Package, ArrowLeft, Menu
} from "lucide-react";

/* ---------------------------------- design tokens ---------------------------------- */
const C = {
  bg: "#FAF5EC",
  panel: "#FFFFFF",
  brown: "#3E241E",
  brownDeep: "#2A1712",
  rust: "#A9603A",
  rustDeep: "#8B4A2A",
  blush: "#EEE0CC",
  line: "#E4D6C1",
  ink: "#2A211D",
  sub: "#8A7B6C",
  gold: "#C79A56",
  ok: "#5B7B54",
  err: "#B4463C",
};

const FONTS = `
@import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600;700&family=Manrope:wght@400;500;600;700&display=swap');
.tnb-root{font-family:'Manrope',sans-serif;color:${C.ink};background:${C.bg};}
.tnb-serif{font-family:'Cormorant Garamond',serif;}
.tnb-root [dir="rtl"]{font-family:'Manrope',sans-serif;}
`;

/* ---------------------------------- i18n ---------------------------------- */
const T = {
  en: {
    home: "Home", shop: "Shop", cart: "Cart", admin: "Admin", search: "Search products",
    heroTitle: "Heritage stitched\ninto every thread", heroSub: "Handcrafted traditional wear from Tanabi International — sizes, colors and prices tailored to you.",
    shopNow: "Shop the collection", featured: "Featured pieces", newArrivals: "New arrivals",
    all: "All", category: "Category", collection: "Collection", addToCart: "Add to cart",
    selectSize: "Select a size", soldOut: "Sold out", off: "OFF", inStock: "in stock",
    yourCart: "Your cart", empty: "Your cart is empty", subtotal: "Subtotal",
    checkout: "Checkout", removeItem: "Remove", continueShopping: "Continue shopping",
    fullName: "Full name", phone: "Phone number", address: "Delivery address",
    placeOrder: "Place order", orderPlaced: "Order placed", orderPlacedSub: "We'll reach out to confirm delivery details.",
    backToShop: "Back to shop", quantity: "Quantity", color: "Color", size: "Size",
    noProducts: "No products match your filters yet.", adminLogin: "Admin sign in",
    password: "Password", enter: "Enter dashboard", wrongPassword: "Incorrect password",
    dashboard: "Dashboard", products: "Products", addProduct: "Add product", editProduct: "Edit product",
    save: "Save product", saveDraft: "Save draft", publish: "Publish", preview: "Preview",
    delete: "Delete", cancel: "Cancel", confirmDelete: "Are you sure you want to delete this product?",
    basicInfo: "Basic information", nameEn: "Product name (English)", nameAr: "Product name (Arabic)",
    shortEn: "Short description (English)", shortAr: "Short description (Arabic)",
    fullEn: "Full description (English)", fullAr: "Full description (Arabic)", sku: "SKU / product code",
    images: "Product images", dragDrop: "Click or drop images here — first image becomes the main photo",
    setMain: "Set as main", pricing: "Pricing", basePrice: "Base price (PKR)", salePrice: "Sale price (PKR, optional)",
    sizes: "Sizes", colors: "Colors", customSize: "Custom size", customColor: "Custom color",
    inventory: "Inventory", stockQty: "Stock quantity", visibility: "Visibility", available: "Available",
    hidden: "Hidden", labels: "Labels", featuredLbl: "Featured product", newArrival: "New arrival",
    bestSeller: "Best seller", status: "Status", updated: "Updated", actions: "Actions",
    filterCategory: "All categories", filterCollection: "All collections", filterStock: "All stock",
    inStockFilter: "In stock", soldOutFilter: "Sold out", draft: "Draft", published: "Published",
    logout: "Log out", currencySettings: "Currency exchange rates", rateNote: "1 PKR equals",
    saveRates: "Save rates", noImages: "No image yet", table: { name: "Product", price: "Price", stock: "Stock" },
  },
  ar: {
    home: "الرئيسية", shop: "المتجر", cart: "السلة", admin: "الإدارة", search: "ابحث عن منتج",
    heroTitle: "تراث منسوج\nفي كل خيط", heroSub: "أزياء تراثية مصنوعة يدوياً من تنابي إنترناشونال — مقاسات وألوان وأسعار تناسبك.",
    shopNow: "تسوّق المجموعة", featured: "قطع مختارة", newArrivals: "وصل حديثاً",
    all: "الكل", category: "الفئة", collection: "المجموعة", addToCart: "أضف إلى السلة",
    selectSize: "اختر مقاس", soldOut: "نفدت الكمية", off: "خصم", inStock: "متوفر",
    yourCart: "سلتك", empty: "سلتك فارغة", subtotal: "المجموع",
    checkout: "إتمام الطلب", removeItem: "إزالة", continueShopping: "متابعة التسوق",
    fullName: "الاسم الكامل", phone: "رقم الهاتف", address: "عنوان التوصيل",
    placeOrder: "تأكيد الطلب", orderPlaced: "تم استلام طلبك", orderPlacedSub: "سنتواصل معك لتأكيد تفاصيل التوصيل.",
    backToShop: "الرجوع للمتجر", quantity: "الكمية", color: "اللون", size: "المقاس",
    noProducts: "لا توجد منتجات تطابق الفلاتر حالياً.", adminLogin: "تسجيل دخول الإدارة",
    password: "كلمة المرور", enter: "دخول لوحة التحكم", wrongPassword: "كلمة المرور غير صحيحة",
    dashboard: "لوحة التحكم", products: "المنتجات", addProduct: "إضافة منتج", editProduct: "تعديل المنتج",
    save: "حفظ المنتج", saveDraft: "حفظ كمسودة", publish: "نشر", preview: "معاينة",
    delete: "حذف", cancel: "إلغاء", confirmDelete: "هل أنت متأكد من حذف هذا المنتج؟",
    basicInfo: "المعلومات الأساسية", nameEn: "اسم المنتج (إنجليزي)", nameAr: "اسم المنتج (عربي)",
    shortEn: "وصف مختصر (إنجليزي)", shortAr: "وصف مختصر (عربي)",
    fullEn: "الوصف الكامل (إنجليزي)", fullAr: "الوصف الكامل (عربي)", sku: "رمز المنتج SKU",
    images: "صور المنتج", dragDrop: "اضغط أو اسحب الصور هنا — أول صورة تصبح الصورة الرئيسية",
    setMain: "اجعلها رئيسية", pricing: "التسعير", basePrice: "السعر الأساسي (روبية باكستانية)", salePrice: "سعر التخفيض (اختياري)",
    sizes: "المقاسات", colors: "الألوان", customSize: "مقاس مخصص", customColor: "لون مخصص",
    inventory: "المخزون", stockQty: "الكمية المتوفرة", visibility: "الظهور", available: "متاح",
    hidden: "مخفي", labels: "الوسوم", featuredLbl: "منتج مميز", newArrival: "وصل حديثاً",
    bestSeller: "الأكثر مبيعاً", status: "الحالة", updated: "آخر تحديث", actions: "إجراءات",
    filterCategory: "كل الفئات", filterCollection: "كل المجموعات", filterStock: "كل المخزون",
    inStockFilter: "متوفر", soldOutFilter: "نفد", draft: "مسودة", published: "منشور",
    logout: "تسجيل خروج", currencySettings: "أسعار صرف العملات", rateNote: "1 روبية باكستانية تساوي",
    saveRates: "حفظ الأسعار", noImages: "لا توجد صورة بعد", table: { name: "المنتج", price: "السعر", stock: "المخزون" },
  },
};

const CUR_SYMBOL = { PKR: "₨", OMR: "ر.ع.", AED: "د.إ", GBP: "£" };
const CURRENCIES = ["PKR", "OMR", "AED", "GBP"];
const SIZE_OPTIONS = ["XS", "S", "M", "L", "XL", "XXL"];
const COLOR_OPTIONS = [
  { name: "Red", hex: "#B23A3A" }, { name: "Black", hex: "#1C1C1C" },
  { name: "Blue", hex: "#3A5B8C" }, { name: "Green", hex: "#3E6B4A" },
  { name: "Beige", hex: "#D8C6A6" }, { name: "Maroon", hex: "#6E2A32" },
];
const CATEGORIES = ["Dresses", "Shawls", "Jewelry", "Footwear", "Accessories"];
const COLLECTIONS = ["Balochi Heritage", "Bridal", "Everyday", "Festive"];
const STORAGE_KEY = "tanabi-store-data";
const ADMIN_PASS = "tanabi2026";

/* ---------------------------------- helpers ---------------------------------- */
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const nowISO = () => new Date().toISOString();

function fieldFor(product, base, lang) {
  const val = product[`${base}_${lang}`];
  return val && val.trim() ? val : product[`${base}_en`] || "";
}

function convert(pkr, currency, rates) {
  if (currency === "PKR") return pkr;
  return pkr * (rates[currency] || 0);
}

function money(amount, currency) {
  const decimals = currency === "PKR" ? 0 : 2;
  const num = amount.toLocaleString(undefined, { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
  return `${CUR_SYMBOL[currency]} ${num}`;
}

function resizeImage(file, maxW = 640, quality = 0.62) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const scale = Math.min(1, maxW / img.width);
        const w = Math.round(img.width * scale);
        const h = Math.round(img.height * scale);
        const canvas = document.createElement("canvas");
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL("image/jpeg", quality));
      };
      img.onerror = reject;
      img.src = e.target.result;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function seedProducts() {
  return [
    {
      id: uid(),
      product_name_en: "Balochi Traditional Dress",
      product_name_ar: "فستان بلوشي تقليدي",
      short_description_en: "Hand-embroidered dress with mirror work and flowing veil.",
      short_description_ar: "فستان مطرز يدوياً بأعمال المرايا مع طرحة انسيابية.",
      description_en: "A statement piece from our Balochi Heritage collection, hand-embroidered by artisans using traditional mirror and thread work. Comes with a matching veil.",
      description_ar: "قطعة مميزة من مجموعة التراث البلوشي، مطرزة يدوياً من قبل حرفيين بأسلوب المرايا والخيوط التقليدي، وتأتي مع طرحة متناسقة.",
      category: "Dresses",
      collection: "Balochi Heritage",
      sku: "TNB-DRS-001",
      base_price_pkr: 25000,
      sale_price_pkr: "",
      images: [],
      main_image: 0,
      sizes: ["S", "M", "L"],
      colors: [{ name: "Beige", hex: "#D8C6A6" }, { name: "Maroon", hex: "#6E2A32" }],
      stock_quantity: 8,
      featured: true,
      new_arrival: true,
      best_seller: false,
      sold_out: false,
      visibility: "available",
      status: "published",
      created_at: nowISO(),
      updated_at: nowISO(),
    },
  ];
}

function defaultData() {
  return {
    products: seedProducts(),
    settings: { rates: { OMR: 0.00138, AED: 0.0129, GBP: 0.0027 } },
    orders: [],
  };
}

/* ---------------------------------- placeholder art ---------------------------------- */
function DressPlaceholder({ tone = C.rust }) {
  return (
    <svg viewBox="0 0 200 260" className="w-full h-full">
      <rect width="200" height="260" fill={C.blush} />
      <circle cx="100" cy="55" r="26" fill={tone} opacity="0.85" />
      <path d="M60 90 Q100 75 140 90 L155 240 Q100 255 45 240 Z" fill={tone} opacity="0.55" />
      <path d="M78 90 L122 90 L128 240 L72 240 Z" fill={tone} opacity="0.8" />
    </svg>
  );
}

/* ---------------------------------- badges ---------------------------------- */
function Badge({ children, tone }) {
  return (
    <span
      className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-semibold tracking-wide rounded-full"
      style={{ background: tone, color: "#fff" }}
    >
      {children}
    </span>
  );
}

/* ================================================================================
   MAIN APP
================================================================================ */
export default function App() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [lang, setLang] = useState("en");
  const [currency, setCurrency] = useState("OMR");
  const [route, setRoute] = useState({ view: "home" }); // home | shop | product | cart | checkout | orderDone
  const [cart, setCart] = useState([]);
  const [adminAuthed, setAdminAuthed] = useState(false);
  const [adminRoute, setAdminRoute] = useState({ view: "products" }); // products | form | settings
  const [inAdmin, setInAdmin] = useState(false);
  const [toast, setToast] = useState("");
  const t = T[lang];
  const dir = lang === "ar" ? "rtl" : "ltr";
  const saveTimer = useRef(null);

  /* ---- load ---- */
  useEffect(() => {
    (async () => {
      try {
        const res = await window.storage.get(STORAGE_KEY, false);
        if (res && res.value) {
          setData(JSON.parse(res.value));
        } else {
          const seed = defaultData();
          setData(seed);
          await window.storage.set(STORAGE_KEY, JSON.stringify(seed), false);
        }
      } catch {
        setData(defaultData());
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  /* ---- persist (debounced) ---- */
  useEffect(() => {
    if (!data) return;
    clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(async () => {
      try {
        await window.storage.set(STORAGE_KEY, JSON.stringify(data), false);
      } catch {}
    }, 350);
    return () => clearTimeout(saveTimer.current);
  }, [data]);

  function showToast(msg) {
    setToast(msg);
    setTimeout(() => setToast(""), 2200);
  }

  const rates = data?.settings?.rates || { OMR: 0.00138, AED: 0.0129, GBP: 0.0027 };

  /* ---- cart ops ---- */
  function addToCart(product, size, color, qty = 1) {
    setCart((prev) => {
      const key = `${product.id}__${size || ""}__${color || ""}`;
      const idx = prev.findIndex((i) => i.key === key);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = { ...copy[idx], qty: copy[idx].qty + qty };
        return copy;
      }
      return [...prev, { key, productId: product.id, size, color, qty }];
    });
    showToast(lang === "ar" ? "أضيف إلى السلة" : "Added to cart");
  }
  function removeFromCart(key) {
    setCart((prev) => prev.filter((i) => i.key !== key));
  }

  /* ---- product CRUD ---- */
  function upsertProduct(product) {
    setData((prev) => {
      const exists = prev.products.some((p) => p.id === product.id);
      const products = exists
        ? prev.products.map((p) => (p.id === product.id ? product : p))
        : [...prev.products, product];
      return { ...prev, products };
    });
  }
  function deleteProduct(id) {
    setData((prev) => ({ ...prev, products: prev.products.filter((p) => p.id !== id) }));
  }
  function placeOrder(orderInfo) {
    setData((prev) => {
      const products = prev.products.map((p) => {
        const items = cart.filter((c) => c.productId === p.id);
        const boughtQty = items.reduce((s, i) => s + i.qty, 0);
        if (!boughtQty) return p;
        const newStock = Math.max(0, p.stock_quantity - boughtQty);
        return { ...p, stock_quantity: newStock, sold_out: newStock === 0, updated_at: nowISO() };
      });
      const order = { id: uid(), items: cart, ...orderInfo, created_at: nowISO() };
      return { ...prev, products, orders: [...prev.orders, order] };
    });
    setCart([]);
    setRoute({ view: "orderDone" });
  }

  if (loading || !data) {
    return (
      <div className="tnb-root min-h-[600px] flex items-center justify-center">
        <style>{FONTS}</style>
        <p className="tnb-serif text-2xl" style={{ color: C.brown }}>Tanabi International…</p>
      </div>
    );
  }

  return (
    <div className="tnb-root min-h-[700px]" dir={dir} style={{ background: C.bg }}>
      <style>{FONTS}</style>

      {toast && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-full text-sm font-medium shadow-lg"
          style={{ background: C.brown, color: "#fff" }}>
          {toast}
        </div>
      )}

      {inAdmin ? (
        <AdminApp
          data={data} setData={setData} t={t} lang={lang} setLang={setLang}
          rates={rates} authed={adminAuthed} setAuthed={setAdminAuthed}
          route={adminRoute} setRoute={setAdminRoute}
          upsertProduct={upsertProduct} deleteProduct={deleteProduct}
          exit={() => setInAdmin(false)} showToast={showToast}
        />
      ) : (
        <StoreApp
          data={data} t={t} lang={lang} setLang={setLang}
          currency={currency} setCurrency={setCurrency} rates={rates}
          route={route} setRoute={setRoute}
          cart={cart} addToCart={addToCart} removeFromCart={removeFromCart}
          placeOrder={placeOrder} openAdmin={() => setInAdmin(true)}
        />
      )}
    </div>
  );
}

/* ================================================================================
   STOREFRONT
================================================================================ */
function StoreApp({ data, t, lang, setLang, currency, setCurrency, rates, route, setRoute, cart, addToCart, removeFromCart, placeOrder, openAdmin }) {
  const products = data.products.filter((p) => p.status === "published" && p.visibility === "available");
  const cartCount = cart.reduce((s, i) => s + i.qty, 0);
  const [cartOpen, setCartOpen] = useState(false);

  return (
    <div>
      <Header
        t={t} lang={lang} setLang={setLang} currency={currency} setCurrency={setCurrency}
        cartCount={cartCount} onCart={() => setCartOpen(true)} setRoute={setRoute} openAdmin={openAdmin}
      />

      {route.view === "home" && (
        <Home t={t} lang={lang} products={products} currency={currency} rates={rates} setRoute={setRoute} />
      )}
      {route.view === "shop" && (
        <Shop t={t} lang={lang} products={products} currency={currency} rates={rates} setRoute={setRoute} />
      )}
      {route.view === "product" && (
        <ProductDetail
          product={data.products.find((p) => p.id === route.id)}
          t={t} lang={lang} currency={currency} rates={rates}
          addToCart={addToCart} setRoute={setRoute}
        />
      )}
      {route.view === "orderDone" && <OrderDone t={t} setRoute={setRoute} />}

      <CartDrawer
        open={cartOpen} onClose={() => setCartOpen(false)}
        cart={cart} products={data.products} t={t} lang={lang} currency={currency} rates={rates}
        removeFromCart={removeFromCart}
        onCheckout={() => { setCartOpen(false); setRoute({ view: "checkout" }); }}
      />

      {route.view === "checkout" && (
        <CheckoutModal
          cart={cart} products={data.products} t={t} lang={lang} currency={currency} rates={rates}
          onClose={() => setRoute({ view: "home" })} placeOrder={placeOrder}
        />
      )}

      <Footer t={t} lang={lang} />
    </div>
  );
}

function Header({ t, lang, setLang, currency, setCurrency, cartCount, onCart, setRoute, openAdmin }) {
  const [menu, setMenu] = useState(false);
  return (
    <header className="sticky top-0 z-40 border-b" style={{ background: C.bg, borderColor: C.line }}>
      <div className="max-w-6xl mx-auto px-5 py-4 flex items-center justify-between gap-3">
        <button onClick={() => setRoute({ view: "home" })} className="text-left">
          <div className="tnb-serif text-2xl font-semibold leading-none" style={{ color: C.brown }}>Tanabi</div>
          <div className="text-[11px] tracking-widest" style={{ color: C.sub }}>INTERNATIONAL</div>
        </button>

        <nav className="hidden md:flex items-center gap-7 text-sm font-medium">
          <button onClick={() => setRoute({ view: "home" })} style={{ color: C.ink }}>{t.home}</button>
          <button onClick={() => setRoute({ view: "shop" })} style={{ color: C.ink }}>{t.shop}</button>
        </nav>

        <div className="flex items-center gap-2">
          <select value={currency} onChange={(e) => setCurrency(e.target.value)}
            className="text-sm rounded-full px-3 py-1.5 border bg-white" style={{ borderColor: C.line }}>
            {CURRENCIES.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
          <button onClick={() => setLang(lang === "en" ? "ar" : "en")}
            className="text-sm rounded-full px-3 py-1.5 border bg-white flex items-center gap-1" style={{ borderColor: C.line }}>
            <Globe size={14} /> {lang === "en" ? "AR" : "EN"}
          </button>
          <button onClick={onCart} className="relative rounded-full p-2 border bg-white" style={{ borderColor: C.line }}>
            <ShoppingBag size={18} style={{ color: C.brown }} />
            {cartCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 text-[10px] w-4 h-4 rounded-full flex items-center justify-center text-white"
                style={{ background: C.rust }}>{cartCount}</span>
            )}
          </button>
          <button onClick={openAdmin} className="hidden sm:flex items-center gap-1 text-xs rounded-full px-3 py-2 border"
            style={{ borderColor: C.line, color: C.sub }}>
            <Lock size={12} /> {t.admin}
          </button>
          <button className="md:hidden p-2" onClick={() => setMenu((m) => !m)}><Menu size={20} /></button>
        </div>
      </div>
      {menu && (
        <div className="md:hidden px-5 pb-4 flex flex-col gap-2 text-sm font-medium">
          <button onClick={() => { setRoute({ view: "home" }); setMenu(false); }} className="text-left">{t.home}</button>
          <button onClick={() => { setRoute({ view: "shop" }); setMenu(false); }} className="text-left">{t.shop}</button>
          <button onClick={openAdmin} className="text-left flex items-center gap-1"><Lock size={12} /> {t.admin}</button>
        </div>
      )}
    </header>
  );
}

function Home({ t, lang, products, currency, rates, setRoute }) {
  const featured = products.filter((p) => p.featured);
  const arrivals = products.filter((p) => p.new_arrival);
  return (
    <div>
      <section className="max-w-6xl mx-auto px-5 pt-10 pb-16 grid md:grid-cols-2 gap-10 items-center">
        <div>
          <h1 className="tnb-serif text-5xl leading-tight whitespace-pre-line" style={{ color: C.brown }}>{t.heroTitle}</h1>
          <p className="mt-5 text-base leading-relaxed max-w-md" style={{ color: C.sub }}>{t.heroSub}</p>
          <button onClick={() => setRoute({ view: "shop" })}
            className="mt-7 px-7 py-3 rounded-full text-sm font-semibold text-white"
            style={{ background: C.brown }}>{t.shopNow}</button>
        </div>
        <div className="rounded-2xl overflow-hidden aspect-[4/5]" style={{ background: C.blush }}>
          <DressPlaceholder tone={C.rustDeep} />
        </div>
      </section>

      {featured.length > 0 && (
        <ProductRow title={t.featured} products={featured} t={t} lang={lang} currency={currency} rates={rates} setRoute={setRoute} />
      )}
      {arrivals.length > 0 && (
        <ProductRow title={t.newArrivals} products={arrivals} t={t} lang={lang} currency={currency} rates={rates} setRoute={setRoute} />
      )}
    </div>
  );
}

function ProductRow({ title, products, t, lang, currency, rates, setRoute }) {
  return (
    <section className="max-w-6xl mx-auto px-5 pb-14">
      <h2 className="tnb-serif text-2xl mb-5" style={{ color: C.brown }}>{title}</h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-5">
        {products.slice(0, 4).map((p) => (
          <ProductCard key={p.id} product={p} t={t} lang={lang} currency={currency} rates={rates} setRoute={setRoute} />
        ))}
      </div>
    </section>
  );
}

function ProductCard({ product, t, lang, currency, rates, setRoute }) {
  const name = fieldFor(product, "product_name", lang);
  const hasImg = product.images && product.images.length > 0;
  const mainImg = hasImg ? product.images[product.main_image || 0] : null;
  const onSale = product.sale_price_pkr && Number(product.sale_price_pkr) > 0 && Number(product.sale_price_pkr) < Number(product.base_price_pkr);
  const discount = onSale ? Math.round((1 - product.sale_price_pkr / product.base_price_pkr) * 100) : 0;
  const displayPrice = convert(onSale ? Number(product.sale_price_pkr) : Number(product.base_price_pkr), currency, rates);
  const regularPrice = convert(Number(product.base_price_pkr), currency, rates);

  return (
    <button onClick={() => setRoute({ view: "product", id: product.id })} className="text-left group">
      <div className="relative rounded-xl overflow-hidden aspect-[4/5]" style={{ background: C.blush }}>
        {mainImg ? <img src={mainImg} alt={name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" /> : <DressPlaceholder />}
        <div className="absolute top-2 left-2 flex flex-col gap-1 items-start">
          {product.sold_out && <Badge tone={C.err}>{t.soldOut}</Badge>}
          {!product.sold_out && product.featured && <Badge tone={C.brown}>★</Badge>}
          {!product.sold_out && onSale && <Badge tone={C.rust}>{discount}% {t.off}</Badge>}
        </div>
      </div>
      <div className="mt-2.5">
        <p className="text-sm font-semibold" style={{ color: C.ink }}>{name}</p>
        <div className="flex items-center gap-2 mt-0.5">
          <span className="text-sm font-semibold" style={{ color: C.rustDeep }}>{money(displayPrice, currency)}</span>
          {onSale && <span className="text-xs line-through" style={{ color: C.sub }}>{money(regularPrice, currency)}</span>}
        </div>
      </div>
    </button>
  );
}

function Shop({ t, lang, products, currency, rates, setRoute }) {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("");
  const [col, setCol] = useState("");

  const filtered = products.filter((p) => {
    const name = fieldFor(p, "product_name", lang).toLowerCase();
    if (q && !name.includes(q.toLowerCase()) && !p.sku.toLowerCase().includes(q.toLowerCase())) return false;
    if (cat && p.category !== cat) return false;
    if (col && p.collection !== col) return false;
    return true;
  });

  return (
    <section className="max-w-6xl mx-auto px-5 py-10">
      <h1 className="tnb-serif text-3xl mb-6" style={{ color: C.brown }}>{t.shop}</h1>
      <div className="flex flex-wrap gap-3 mb-7">
        <div className="relative flex-1 min-w-[200px]">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: C.sub }} />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t.search}
            className="w-full pl-9 pr-3 py-2.5 rounded-full border text-sm" style={{ borderColor: C.line }} />
        </div>
        <select value={cat} onChange={(e) => setCat(e.target.value)} className="rounded-full border px-3 py-2.5 text-sm" style={{ borderColor: C.line }}>
          <option value="">{t.filterCategory}</option>
          {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
        <select value={col} onChange={(e) => setCol(e.target.value)} className="rounded-full border px-3 py-2.5 text-sm" style={{ borderColor: C.line }}>
          <option value="">{t.filterCollection}</option>
          {COLLECTIONS.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      {filtered.length === 0 ? (
        <p className="py-16 text-center" style={{ color: C.sub }}>{t.noProducts}</p>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-5">
          {filtered.map((p) => (
            <ProductCard key={p.id} product={p} t={t} lang={lang} currency={currency} rates={rates} setRoute={setRoute} />
          ))}
        </div>
      )}
    </section>
  );
}

function ProductDetail({ product, t, lang, currency, rates, addToCart, setRoute }) {
  const [imgIdx, setImgIdx] = useState(0);
  const [size, setSize] = useState("");
  const [color, setColor] = useState("");
  const [qty, setQty] = useState(1);

  if (!product) return <div className="max-w-3xl mx-auto px-5 py-20 text-center">Not found</div>;

  const name = fieldFor(product, "product_name", lang);
  const shortDesc = fieldFor(product, "short_description", lang);
  const fullDesc = fieldFor(product, "description", lang);
  const images = product.images || [];
  const hasImgs = images.length > 0;
  const onSale = product.sale_price_pkr && Number(product.sale_price_pkr) > 0 && Number(product.sale_price_pkr) < Number(product.base_price_pkr);
  const discount = onSale ? Math.round((1 - product.sale_price_pkr / product.base_price_pkr) * 100) : 0;
  const displayPrice = convert(onSale ? Number(product.sale_price_pkr) : Number(product.base_price_pkr), currency, rates);
  const regularPrice = convert(Number(product.base_price_pkr), currency, rates);
  const needsSize = product.sizes && product.sizes.length > 0;
  const canAdd = !product.sold_out && (!needsSize || size);

  return (
    <section className="max-w-5xl mx-auto px-5 py-8">
      <button onClick={() => setRoute({ view: "shop" })} className="flex items-center gap-1 text-sm mb-6" style={{ color: C.sub }}>
        <ArrowLeft size={14} /> {t.backToShop}
      </button>
      <div className="grid md:grid-cols-2 gap-10">
        <div>
          <div className="rounded-2xl overflow-hidden aspect-[4/5]" style={{ background: C.blush }}>
            {hasImgs ? <img src={images[imgIdx]} alt={name} className="w-full h-full object-cover" /> : <DressPlaceholder />}
          </div>
          {images.length > 1 && (
            <div className="flex gap-2 mt-3">
              {images.map((im, i) => (
                <button key={i} onClick={() => setImgIdx(i)} className="w-16 h-16 rounded-lg overflow-hidden border-2"
                  style={{ borderColor: i === imgIdx ? C.rust : "transparent" }}>
                  <img src={im} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        <div>
          <div className="flex gap-2 mb-2">
            {product.featured && <Badge tone={C.brown}>{t.featured}</Badge>}
            {product.new_arrival && <Badge tone={C.gold}>{t.newArrivals}</Badge>}
          </div>
          <h1 className="tnb-serif text-3xl" style={{ color: C.brown }}>{name}</h1>
          <p className="mt-2 text-sm" style={{ color: C.sub }}>{shortDesc}</p>

          <div className="flex items-center gap-3 mt-4">
            <span className="text-2xl font-semibold" style={{ color: C.rustDeep }}>{money(displayPrice, currency)}</span>
            {onSale && <span className="line-through text-sm" style={{ color: C.sub }}>{money(regularPrice, currency)}</span>}
            {onSale && <Badge tone={C.rust}>{discount}% {t.off}</Badge>}
          </div>

          {needsSize && (
            <div className="mt-6">
              <p className="text-sm font-semibold mb-2">{t.size}</p>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map((s) => (
                  <button key={s} onClick={() => setSize(s)}
                    className="w-11 h-11 rounded-full border text-sm font-medium"
                    style={{ borderColor: size === s ? C.brown : C.line, background: size === s ? C.brown : "#fff", color: size === s ? "#fff" : C.ink }}>
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {product.colors && product.colors.length > 0 && (
            <div className="mt-6">
              <p className="text-sm font-semibold mb-2">{t.color}</p>
              <div className="flex flex-wrap gap-2">
                {product.colors.map((c) => (
                  <button key={c.name} onClick={() => setColor(c.name)}
                    className="w-9 h-9 rounded-full border-2"
                    style={{ background: c.hex, borderColor: color === c.name ? C.brown : "#fff", boxShadow: `0 0 0 1px ${C.line}` }}
                    title={c.name} />
                ))}
              </div>
            </div>
          )}

          <div className="mt-6 flex items-center gap-3">
            <div className="flex items-center border rounded-full" style={{ borderColor: C.line }}>
              <button onClick={() => setQty((q) => Math.max(1, q - 1))} className="w-9 h-9">-</button>
              <span className="w-8 text-center text-sm">{qty}</span>
              <button onClick={() => setQty((q) => q + 1)} className="w-9 h-9">+</button>
            </div>
            <button
              disabled={!canAdd}
              onClick={() => addToCart(product, size, color, qty)}
              className="flex-1 py-3 rounded-full text-sm font-semibold text-white disabled:opacity-40"
              style={{ background: product.sold_out ? C.sub : C.brown }}>
              {product.sold_out ? t.soldOut : (needsSize && !size ? t.selectSize : t.addToCart)}
            </button>
          </div>

          {fullDesc && <p className="mt-7 text-sm leading-relaxed" style={{ color: C.sub }}>{fullDesc}</p>}
          {!product.sold_out && (
            <p className="mt-4 text-xs" style={{ color: C.ok }}>{product.stock_quantity} {t.inStock}</p>
          )}
        </div>
      </div>
    </section>
  );
}

function CartDrawer({ open, onClose, cart, products, t, lang, currency, rates, removeFromCart, onCheckout }) {
  if (!open) return null;
  const lines = cart.map((c) => {
    const p = products.find((pp) => pp.id === c.productId);
    return { ...c, p };
  }).filter((l) => l.p);
  const total = lines.reduce((sum, l) => {
    const onSale = l.p.sale_price_pkr && Number(l.p.sale_price_pkr) > 0 && Number(l.p.sale_price_pkr) < Number(l.p.base_price_pkr);
    const unit = convert(onSale ? Number(l.p.sale_price_pkr) : Number(l.p.base_price_pkr), currency, rates);
    return sum + unit * l.qty;
  }, 0);

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <div className="absolute inset-0 bg-black/30" onClick={onClose} />
      <div className="relative w-full max-w-sm bg-white h-full flex flex-col" style={{ background: C.panel }}>
        <div className="flex items-center justify-between px-5 py-4 border-b" style={{ borderColor: C.line }}>
          <h2 className="tnb-serif text-xl" style={{ color: C.brown }}>{t.yourCart}</h2>
          <button onClick={onClose}><X size={20} /></button>
        </div>
        <div className="flex-1 overflow-auto px-5 py-4">
          {lines.length === 0 ? (
            <p className="text-sm text-center py-10" style={{ color: C.sub }}>{t.empty}</p>
          ) : lines.map((l) => {
            const name = fieldFor(l.p, "product_name", lang);
            const img = l.p.images && l.p.images[l.p.main_image || 0];
            return (
              <div key={l.key} className="flex gap-3 py-3 border-b" style={{ borderColor: C.line }}>
                <div className="w-16 h-16 rounded-lg overflow-hidden shrink-0" style={{ background: C.blush }}>
                  {img ? <img src={img} className="w-full h-full object-cover" /> : <DressPlaceholder />}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium">{name}</p>
                  <p className="text-xs mt-0.5" style={{ color: C.sub }}>
                    {[l.size, l.color].filter(Boolean).join(" · ")} · x{l.qty}
                  </p>
                </div>
                <button onClick={() => removeFromCart(l.key)}><Trash2 size={16} style={{ color: C.sub }} /></button>
              </div>
            );
          })}
        </div>
        <div className="px-5 py-4 border-t" style={{ borderColor: C.line }}>
          <div className="flex justify-between text-sm mb-3">
            <span>{t.subtotal}</span>
            <span className="font-semibold">{money(total, currency)}</span>
          </div>
          <button disabled={lines.length === 0} onClick={onCheckout}
            className="w-full py-3 rounded-full text-sm font-semibold text-white disabled:opacity-40" style={{ background: C.brown }}>
            {t.checkout}
          </button>
        </div>
      </div>
    </div>
  );
}

function CheckoutModal({ cart, products, t, lang, currency, rates, onClose, placeOrder }) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const valid = name && phone && address;

  const lines = cart.map((c) => ({ ...c, p: products.find((pp) => pp.id === c.productId) })).filter((l) => l.p);
  const total = lines.reduce((sum, l) => {
    const onSale = l.p.sale_price_pkr && Number(l.p.sale_price_pkr) > 0 && Number(l.p.sale_price_pkr) < Number(l.p.base_price_pkr);
    const unit = convert(onSale ? Number(l.p.sale_price_pkr) : Number(l.p.base_price_pkr), currency, rates);
    return sum + unit * l.qty;
  }, 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative bg-white rounded-2xl max-w-md w-full p-6" style={{ background: C.panel }}>
        <div className="flex justify-between items-center mb-4">
          <h2 className="tnb-serif text-2xl" style={{ color: C.brown }}>{t.checkout}</h2>
          <button onClick={onClose}><X size={20} /></button>
        </div>
        <div className="space-y-3">
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder={t.fullName}
            className="w-full px-3 py-2.5 rounded-lg border text-sm" style={{ borderColor: C.line }} />
          <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder={t.phone}
            className="w-full px-3 py-2.5 rounded-lg border text-sm" style={{ borderColor: C.line }} />
          <textarea value={address} onChange={(e) => setAddress(e.target.value)} placeholder={t.address} rows={3}
            className="w-full px-3 py-2.5 rounded-lg border text-sm" style={{ borderColor: C.line }} />
        </div>
        <div className="flex justify-between text-sm mt-4 mb-2">
          <span>{t.subtotal}</span>
          <span className="font-semibold">{money(total, currency)}</span>
        </div>
        <button disabled={!valid} onClick={() => placeOrder({ name, phone, address, currency, total })}
          className="w-full py-3 rounded-full text-sm font-semibold text-white disabled:opacity-40 mt-2" style={{ background: C.brown }}>
          {t.placeOrder}
        </button>
      </div>
    </div>
  );
}

function OrderDone({ t, setRoute }) {
  return (
    <div className="max-w-md mx-auto px-5 py-24 text-center">
      <div className="w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-5" style={{ background: C.ok }}>
        <Check size={26} color="#fff" />
      </div>
      <h1 className="tnb-serif text-3xl" style={{ color: C.brown }}>{t.orderPlaced}</h1>
      <p className="mt-2 text-sm" style={{ color: C.sub }}>{t.orderPlacedSub}</p>
      <button onClick={() => setRoute({ view: "shop" })} className="mt-6 px-6 py-3 rounded-full text-sm font-semibold text-white" style={{ background: C.brown }}>
        {t.continueShopping}
      </button>
    </div>
  );
}

function Footer({ t, lang }) {
  return (
    <footer className="border-t mt-10 py-8 text-center text-xs" style={{ borderColor: C.line, color: C.sub }}>
      Tanabi International · {lang === "ar" ? "نموذج تجريبي" : "Demo prototype"}
    </footer>
  );
}

/* ================================================================================
   ADMIN
================================================================================ */
function AdminApp({ data, setData, t, lang, setLang, rates, authed, setAuthed, route, setRoute, upsertProduct, deleteProduct, exit, showToast }) {
  const [pass, setPass] = useState("");
  const [err, setErr] = useState(false);

  if (!authed) {
    return (
      <div className="min-h-[600px] flex items-center justify-center px-5">
        <div className="w-full max-w-sm bg-white rounded-2xl p-7 border" style={{ borderColor: C.line }}>
          <button onClick={exit} className="text-xs mb-4 flex items-center gap-1" style={{ color: C.sub }}>
            <ArrowLeft size={12} /> {t.backToShop}
          </button>
          <h1 className="tnb-serif text-2xl mb-1" style={{ color: C.brown }}>{t.adminLogin}</h1>
          <p className="text-xs mb-5" style={{ color: C.sub }}>Tanabi International</p>
          <input type="password" value={pass} onChange={(e) => { setPass(e.target.value); setErr(false); }}
            placeholder={t.password} className="w-full px-3 py-2.5 rounded-lg border text-sm mb-2" style={{ borderColor: C.line }}
            onKeyDown={(e) => e.key === "Enter" && (pass === ADMIN_PASS ? setAuthed(true) : setErr(true))} />
          {err && <p className="text-xs mb-2" style={{ color: C.err }}>{t.wrongPassword}</p>}
          <button onClick={() => (pass === ADMIN_PASS ? setAuthed(true) : setErr(true))}
            className="w-full py-2.5 rounded-full text-sm font-semibold text-white mt-2" style={{ background: C.brown }}>
            {t.enter}
          </button>
          <p className="text-[11px] mt-3" style={{ color: C.sub }}>Demo password: {ADMIN_PASS}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[600px]">
      <div className="border-b bg-white" style={{ borderColor: C.line }}>
        <div className="max-w-6xl mx-auto px-5 py-4 flex items-center justify-between">
          <div>
            <span className="tnb-serif text-xl" style={{ color: C.brown }}>{t.dashboard}</span>
            <span className="text-xs ml-2" style={{ color: C.sub }}>Tanabi International</span>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => setLang(lang === "en" ? "ar" : "en")} className="text-xs rounded-full px-3 py-1.5 border">{lang === "en" ? "AR" : "EN"}</button>
            <button onClick={() => setRoute({ view: "settings" })} className="text-xs rounded-full px-3 py-1.5 border flex items-center gap-1" style={{ borderColor: C.line }}>
              <SettingsIcon size={13} /> {t.currencySettings}
            </button>
            <button onClick={exit} className="text-xs rounded-full px-3 py-1.5 border" style={{ borderColor: C.line }}>{t.backToShop}</button>
            <button onClick={() => setAuthed(false)} className="text-xs rounded-full px-3 py-1.5" style={{ color: C.err }}>{t.logout}</button>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-5 py-6">
        {route.view === "products" && (
          <ProductTable data={data} t={t} lang={lang} rates={rates} setRoute={setRoute} deleteProduct={deleteProduct} upsertProduct={upsertProduct} showToast={showToast} />
        )}
        {route.view === "form" && (
          <ProductForm t={t} lang={lang} product={route.product} upsertProduct={upsertProduct} setRoute={setRoute} showToast={showToast} />
        )}
        {route.view === "settings" && (
          <CurrencySettings t={t} rates={rates} setData={setData} setRoute={setRoute} showToast={showToast} />
        )}
      </div>
    </div>
  );
}

function ProductTable({ data, t, lang, rates, setRoute, deleteProduct, upsertProduct, showToast }) {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("");
  const [stock, setStock] = useState("");
  const [confirmId, setConfirmId] = useState(null);

  const rows = data.products.filter((p) => {
    const name = fieldFor(p, "product_name", "en").toLowerCase();
    if (q && !name.includes(q.toLowerCase()) && !p.sku.toLowerCase().includes(q.toLowerCase())) return false;
    if (cat && p.category !== cat) return false;
    if (stock === "in" && p.sold_out) return false;
    if (stock === "out" && !p.sold_out) return false;
    return true;
  });

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3 mb-5">
        <h1 className="tnb-serif text-2xl" style={{ color: C.brown }}>{t.products}</h1>
        <button onClick={() => setRoute({ view: "form", product: null })}
          className="flex items-center gap-1.5 px-4 py-2.5 rounded-full text-sm font-semibold text-white" style={{ background: C.brown }}>
          <Plus size={15} /> {t.addProduct}
        </button>
      </div>

      <div className="flex flex-wrap gap-3 mb-4">
        <div className="relative flex-1 min-w-[180px]">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: C.sub }} />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t.search}
            className="w-full pl-9 pr-3 py-2 rounded-full border text-sm" style={{ borderColor: C.line }} />
        </div>
        <select value={cat} onChange={(e) => setCat(e.target.value)} className="rounded-full border px-3 py-2 text-sm" style={{ borderColor: C.line }}>
          <option value="">{t.filterCategory}</option>
          {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
        <select value={stock} onChange={(e) => setStock(e.target.value)} className="rounded-full border px-3 py-2 text-sm" style={{ borderColor: C.line }}>
          <option value="">{t.filterStock}</option>
          <option value="in">{t.inStockFilter}</option>
          <option value="out">{t.soldOutFilter}</option>
        </select>
      </div>

      <div className="overflow-x-auto rounded-xl border" style={{ borderColor: C.line }}>
        <table className="w-full text-sm bg-white">
          <thead>
            <tr className="text-left border-b" style={{ borderColor: C.line, color: C.sub }}>
              <th className="py-2.5 px-3 font-medium"></th>
              <th className="py-2.5 px-3 font-medium">{t.table.name}</th>
              <th className="py-2.5 px-3 font-medium">{t.sku}</th>
              <th className="py-2.5 px-3 font-medium">{t.table.price}</th>
              <th className="py-2.5 px-3 font-medium">{t.table.stock}</th>
              <th className="py-2.5 px-3 font-medium">{t.status}</th>
              <th className="py-2.5 px-3 font-medium">{t.labels}</th>
              <th className="py-2.5 px-3 font-medium">{t.actions}</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((p) => {
              const img = p.images && p.images[p.main_image || 0];
              return (
                <tr key={p.id} className="border-b last:border-0" style={{ borderColor: C.line }}>
                  <td className="p-3">
                    <div className="w-10 h-10 rounded-lg overflow-hidden" style={{ background: C.blush }}>
                      {img ? <img src={img} className="w-full h-full object-cover" /> : <DressPlaceholder />}
                    </div>
                  </td>
                  <td className="p-3 font-medium">{fieldFor(p, "product_name", "en")}</td>
                  <td className="p-3" style={{ color: C.sub }}>{p.sku}</td>
                  <td className="p-3">{money(Number(p.base_price_pkr), "PKR")}</td>
                  <td className="p-3">{p.sold_out ? <span style={{ color: C.err }}>{t.soldOut}</span> : p.stock_quantity}</td>
                  <td className="p-3">
                    <span className="text-xs px-2 py-1 rounded-full" style={{ background: p.status === "published" ? "#E7EFE4" : "#F2E9D8", color: p.status === "published" ? C.ok : C.gold }}>
                      {p.status === "published" ? t.published : t.draft}
                    </span>
                  </td>
                  <td className="p-3">
                    <div className="flex gap-1 flex-wrap">
                      {p.featured && <Star size={13} style={{ color: C.gold }} />}
                      {p.new_arrival && <Sparkles size={13} style={{ color: C.rust }} />}
                      {p.best_seller && <Award size={13} style={{ color: C.brown }} />}
                    </div>
                  </td>
                  <td className="p-3">
                    <div className="flex gap-2">
                      <button onClick={() => setRoute({ view: "form", product: p })} title={t.editProduct}><Edit2 size={15} style={{ color: C.ink }} /></button>
                      <button onClick={() => setRoute({ view: "form", product: p, previewOnly: true })} title={t.preview}><Eye size={15} style={{ color: C.ink }} /></button>
                      <button onClick={() => upsertProduct({ ...p, id: uid(), product_name_en: p.product_name_en + " (Copy)", sku: p.sku + "-COPY", updated_at: nowISO(), created_at: nowISO() })} title="Duplicate"><Copy size={15} style={{ color: C.ink }} /></button>
                      <button onClick={() => setConfirmId(p.id)} title={t.delete}><Trash2 size={15} style={{ color: C.err }} /></button>
                    </div>
                  </td>
                </tr>
              );
            })}
            {rows.length === 0 && (
              <tr><td colSpan={8} className="p-8 text-center" style={{ color: C.sub }}>{t.noProducts}</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {confirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/40" onClick={() => setConfirmId(null)} />
          <div className="relative bg-white rounded-2xl max-w-sm w-full p-6 text-center">
            <AlertCircle size={28} style={{ color: C.err }} className="mx-auto mb-3" />
            <p className="text-sm mb-5">{t.confirmDelete}</p>
            <div className="flex gap-3">
              <button onClick={() => setConfirmId(null)} className="flex-1 py-2.5 rounded-full border text-sm" style={{ borderColor: C.line }}>{t.cancel}</button>
              <button onClick={() => { deleteProduct(confirmId); setConfirmId(null); showToast("Deleted"); }}
                className="flex-1 py-2.5 rounded-full text-sm text-white" style={{ background: C.err }}>{t.delete}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ProductForm({ t, lang, product, upsertProduct, setRoute, showToast }) {
  const isNew = !product;
  const [form, setForm] = useState(() => product ? { ...product } : {
    id: uid(), product_name_en: "", product_name_ar: "", short_description_en: "", short_description_ar: "",
    description_en: "", description_ar: "", category: CATEGORIES[0], collection: COLLECTIONS[0], sku: "",
    base_price_pkr: "", sale_price_pkr: "", images: [], main_image: 0, sizes: [], colors: [],
    stock_quantity: 0, featured: false, new_arrival: false, best_seller: false, sold_out: false,
    visibility: "available", status: "draft", created_at: nowISO(), updated_at: nowISO(),
  });
  const [customSize, setCustomSize] = useState("");
  const [customColor, setCustomColor] = useState("");
  const [preview, setPreview] = useState(false);
  const fileRef = useRef(null);

  function set(field, val) { setForm((f) => ({ ...f, [field]: val })); }

  async function handleFiles(files) {
    const arr = Array.from(files).slice(0, 8);
    const encoded = await Promise.all(arr.map((f) => resizeImage(f)));
    setForm((f) => ({ ...f, images: [...f.images, ...encoded] }));
  }

  function removeImage(idx) {
    setForm((f) => {
      const images = f.images.filter((_, i) => i !== idx);
      let main = f.main_image;
      if (idx === f.main_image) main = 0;
      else if (idx < f.main_image) main = f.main_image - 1;
      return { ...f, images, main_image: Math.max(0, main) };
    });
  }

  function toggleSize(s) {
    setForm((f) => ({ ...f, sizes: f.sizes.includes(s) ? f.sizes.filter((x) => x !== s) : [...f.sizes, s] }));
  }
  function toggleColor(c) {
    setForm((f) => {
      const exists = f.colors.some((x) => x.name === c.name);
      return { ...f, colors: exists ? f.colors.filter((x) => x.name !== c.name) : [...f.colors, c] };
    });
  }

  function save(status) {
    if (!form.product_name_en || !form.base_price_pkr) {
      showToast(lang === "ar" ? "الاسم والسعر مطلوبان" : "Name and price are required");
      return;
    }
    const soldOut = Number(form.stock_quantity) <= 0;
    const finalForm = { ...form, status, sold_out: soldOut, updated_at: nowISO() };
    upsertProduct(finalForm);
    showToast(status === "published" ? t.publish : t.saveDraft);
    setRoute({ view: "products" });
  }

  const discountPct = form.sale_price_pkr && form.base_price_pkr
    ? Math.round((1 - Number(form.sale_price_pkr) / Number(form.base_price_pkr)) * 100) : 0;

  if (preview) {
    return (
      <div>
        <button onClick={() => setPreview(false)} className="flex items-center gap-1 text-sm mb-4" style={{ color: C.sub }}>
          <ArrowLeft size={14} /> {t.editProduct}
        </button>
        <div className="border rounded-2xl p-6 bg-white" style={{ borderColor: C.line }}>
          <ProductDetail product={form} t={t} lang={lang} currency="PKR" rates={{}} addToCart={() => {}} setRoute={() => {}} />
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl">
      <button onClick={() => setRoute({ view: "products" })} className="flex items-center gap-1 text-sm mb-4" style={{ color: C.sub }}>
        <ArrowLeft size={14} /> {t.products}
      </button>
      <h1 className="tnb-serif text-2xl mb-6" style={{ color: C.brown }}>{isNew ? t.addProduct : t.editProduct}</h1>

      <FormSection title={t.basicInfo}>
        <div className="grid sm:grid-cols-2 gap-3">
          <Field label={t.nameEn}><input value={form.product_name_en} onChange={(e) => set("product_name_en", e.target.value)} className="in" /></Field>
          <Field label={t.nameAr}><input dir="rtl" value={form.product_name_ar} onChange={(e) => set("product_name_ar", e.target.value)} className="in" /></Field>
          <Field label={t.shortEn}><input value={form.short_description_en} onChange={(e) => set("short_description_en", e.target.value)} className="in" /></Field>
          <Field label={t.shortAr}><input dir="rtl" value={form.short_description_ar} onChange={(e) => set("short_description_ar", e.target.value)} className="in" /></Field>
        </div>
        <Field label={t.fullEn}><textarea rows={3} value={form.description_en} onChange={(e) => set("description_en", e.target.value)} className="in" /></Field>
        <Field label={t.fullAr}><textarea dir="rtl" rows={3} value={form.description_ar} onChange={(e) => set("description_ar", e.target.value)} className="in" /></Field>
        <div className="grid sm:grid-cols-3 gap-3">
          <Field label={t.category}>
            <select value={form.category} onChange={(e) => set("category", e.target.value)} className="in">
              {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
            </select>
          </Field>
          <Field label={t.collection}>
            <select value={form.collection} onChange={(e) => set("collection", e.target.value)} className="in">
              {COLLECTIONS.map((c) => <option key={c}>{c}</option>)}
            </select>
          </Field>
          <Field label={t.sku}><input value={form.sku} onChange={(e) => set("sku", e.target.value)} className="in" /></Field>
        </div>
      </FormSection>

      <FormSection title={t.images}>
        <div onClick={() => fileRef.current.click()}
          onDrop={(e) => { e.preventDefault(); handleFiles(e.dataTransfer.files); }}
          onDragOver={(e) => e.preventDefault()}
          className="border-2 border-dashed rounded-xl py-8 text-center cursor-pointer text-sm" style={{ borderColor: C.line, color: C.sub }}>
          <Upload size={20} className="mx-auto mb-2" />
          {t.dragDrop}
        </div>
        <input ref={fileRef} type="file" multiple accept="image/*" className="hidden" onChange={(e) => handleFiles(e.target.files)} />
        {form.images.length === 0 ? (
          <p className="text-xs mt-2" style={{ color: C.sub }}>{t.noImages}</p>
        ) : (
          <div className="flex flex-wrap gap-3 mt-3">
            {form.images.map((im, i) => (
              <div key={i} className="relative w-24 h-24 rounded-lg overflow-hidden border-2" style={{ borderColor: i === form.main_image ? C.rust : C.line }}>
                <img src={im} className="w-full h-full object-cover" />
                {i === form.main_image && <div className="absolute bottom-0 inset-x-0 text-[10px] text-center py-0.5 text-white" style={{ background: C.rust }}>{t.setMain}</div>}
                <div className="absolute top-1 right-1 flex gap-1">
                  {i !== form.main_image && (
                    <button onClick={() => set("main_image", i)} className="w-5 h-5 bg-white/90 rounded-full text-[10px]">★</button>
                  )}
                  <button onClick={() => removeImage(i)} className="w-5 h-5 bg-white/90 rounded-full flex items-center justify-center">
                    <X size={11} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </FormSection>

      <FormSection title={t.pricing}>
        <div className="grid sm:grid-cols-2 gap-3">
          <Field label={t.basePrice}><input type="number" value={form.base_price_pkr} onChange={(e) => set("base_price_pkr", e.target.value)} className="in" /></Field>
          <Field label={t.salePrice}><input type="number" value={form.sale_price_pkr} onChange={(e) => set("sale_price_pkr", e.target.value)} className="in" /></Field>
        </div>
        {discountPct > 0 && <p className="text-xs mt-1" style={{ color: C.ok }}>{discountPct}% {t.off}</p>}
        {form.base_price_pkr > 0 && (
          <div className="flex flex-wrap gap-3 mt-2 text-xs" style={{ color: C.sub }}>
            {CURRENCIES.filter((c) => c !== "PKR").map((c) => (
              <span key={c}>{c}: {money(convert(Number(form.sale_price_pkr || form.base_price_pkr), c, { OMR: 0.00138, AED: 0.0129, GBP: 0.0027 }), c)}</span>
            ))}
          </div>
        )}
      </FormSection>

      <FormSection title={t.sizes}>
        <div className="flex flex-wrap gap-2">
          {SIZE_OPTIONS.map((s) => (
            <button key={s} onClick={() => toggleSize(s)} className="px-3 py-1.5 rounded-full border text-sm"
              style={{ borderColor: form.sizes.includes(s) ? C.brown : C.line, background: form.sizes.includes(s) ? C.brown : "#fff", color: form.sizes.includes(s) ? "#fff" : C.ink }}>
              {s}
            </button>
          ))}
          {form.sizes.filter((s) => !SIZE_OPTIONS.includes(s)).map((s) => (
            <button key={s} onClick={() => toggleSize(s)} className="px-3 py-1.5 rounded-full text-sm text-white" style={{ background: C.brown }}>{s} ×</button>
          ))}
        </div>
        <div className="flex gap-2 mt-2">
          <input value={customSize} onChange={(e) => setCustomSize(e.target.value)} placeholder={t.customSize} className="in flex-1" />
          <button onClick={() => { if (customSize) { toggleSize(customSize); setCustomSize(""); } }} className="px-3 rounded-lg border text-sm" style={{ borderColor: C.line }}>+</button>
        </div>
      </FormSection>

      <FormSection title={t.colors}>
        <div className="flex flex-wrap gap-2">
          {COLOR_OPTIONS.map((c) => (
            <button key={c.name} onClick={() => toggleColor(c)} className="w-9 h-9 rounded-full border-2"
              style={{ background: c.hex, borderColor: form.colors.some((x) => x.name === c.name) ? C.brown : "#fff", boxShadow: `0 0 0 1px ${C.line}` }} title={c.name} />
          ))}
        </div>
        <div className="flex gap-2 mt-2">
          <input value={customColor} onChange={(e) => setCustomColor(e.target.value)} placeholder={t.customColor} className="in flex-1" />
          <button onClick={() => { if (customColor) { toggleColor({ name: customColor, hex: "#B08968" }); setCustomColor(""); } }} className="px-3 rounded-lg border text-sm" style={{ borderColor: C.line }}>+</button>
        </div>
      </FormSection>

      <FormSection title={t.inventory}>
        <div className="grid sm:grid-cols-2 gap-3">
          <Field label={t.stockQty}><input type="number" value={form.stock_quantity} onChange={(e) => set("stock_quantity", e.target.value)} className="in" /></Field>
          <Field label={t.visibility}>
            <select value={form.visibility} onChange={(e) => set("visibility", e.target.value)} className="in">
              <option value="available">{t.available}</option>
              <option value="hidden">{t.hidden}</option>
            </select>
          </Field>
        </div>
        {Number(form.stock_quantity) <= 0 && <p className="text-xs mt-1" style={{ color: C.err }}>{t.soldOut}</p>}
      </FormSection>

      <FormSection title={t.labels}>
        <div className="flex flex-wrap gap-4">
          {[["featured", t.featuredLbl], ["new_arrival", t.newArrival], ["best_seller", t.bestSeller]].map(([key, label]) => (
            <label key={key} className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={form[key]} onChange={(e) => set(key, e.target.checked)} /> {label}
            </label>
          ))}
        </div>
      </FormSection>

      <div className="flex flex-wrap gap-3 mt-6 mb-10">
        <button onClick={() => save("draft")} className="px-5 py-2.5 rounded-full border text-sm font-medium" style={{ borderColor: C.line }}>{t.saveDraft}</button>
        <button onClick={() => setPreview(true)} className="px-5 py-2.5 rounded-full border text-sm font-medium flex items-center gap-1.5" style={{ borderColor: C.line }}><Eye size={14} /> {t.preview}</button>
        <button onClick={() => save("published")} className="px-5 py-2.5 rounded-full text-sm font-semibold text-white" style={{ background: C.brown }}>{t.publish}</button>
      </div>
      <style>{`.in{width:100%;padding:.55rem .75rem;border:1px solid ${C.line};border-radius:.6rem;font-size:.875rem;background:#fff}`}</style>
    </div>
  );
}

function FormSection({ title, children }) {
  return (
    <div className="bg-white border rounded-xl p-5 mb-4" style={{ borderColor: C.line }}>
      <h3 className="text-sm font-semibold mb-3" style={{ color: C.brown }}>{title}</h3>
      <div className="space-y-3">{children}</div>
    </div>
  );
}
function Field({ label, children }) {
  return (
    <div>
      <label className="block text-xs font-medium mb-1" style={{ color: C.sub }}>{label}</label>
      {children}
    </div>
  );
}

function CurrencySettings({ t, rates, setData, setRoute, showToast }) {
  const [local, setLocal] = useState(rates);
  function save() {
    setData((prev) => ({ ...prev, settings: { ...prev.settings, rates: local } }));
    showToast(t.saveRates);
    setRoute({ view: "products" });
  }
  return (
    <div className="max-w-md">
      <button onClick={() => setRoute({ view: "products" })} className="flex items-center gap-1 text-sm mb-4" style={{ color: C.sub }}>
        <ArrowLeft size={14} /> {t.products}
      </button>
      <h1 className="tnb-serif text-2xl mb-5" style={{ color: C.brown }}>{t.currencySettings}</h1>
      <div className="bg-white border rounded-xl p-5 space-y-4" style={{ borderColor: C.line }}>
        {["OMR", "AED", "GBP"].map((c) => (
          <div key={c}>
            <label className="block text-xs font-medium mb-1" style={{ color: C.sub }}>{t.rateNote} {c}</label>
            <input type="number" step="0.0001" value={local[c]} onChange={(e) => setLocal((l) => ({ ...l, [c]: Number(e.target.value) }))}
              className="in" style={{ width: "100%", padding: ".55rem .75rem", border: `1px solid ${C.line}`, borderRadius: ".6rem", fontSize: ".875rem" }} />
          </div>
        ))}
        <button onClick={save} className="w-full py-2.5 rounded-full text-sm font-semibold text-white" style={{ background: C.brown }}>{t.saveRates}</button>
      </div>
    </div>
  );
}